#include "ck_means.h"

CK_means::CK_means()
{
    /**
     * 初始化参数
     */
    assignSampleCenter = new double[MAXDATACOUNT];
    memset(Samples, 0, sizeof(double) * MAXDATACOUNT);
    memset(centerX, 0x0, sizeof(double) * MAXCLUSTER);
    memset(oldcenterX, 0x0, sizeof(double) * MAXCLUSTER);
    k = 2;
    memset(centroidcount, 0, sizeof(int) * MAXCLUSTER);
    memset(classK, 0, sizeof(classK));
    i32SampleIndex = 0;

    centerX[0] = 20337.50;
    centerX[1] = 52224;
}

/**
 * @brief CK_means::AddSamples
 * @param x
 * 增加样本数据
 */
void CK_means::AddSamples(double x)
{
    Samples[i32SampleIndex] = x;

    i32SampleIndex ++;
    i32SampleIndex = i32SampleIndex % MAXDATACOUNT;

}

/**
 * @brief CK_means::calculateDistance
 * @param x1
 * @param x2
 * @return
 * 计算两个数据的距离
 */
double CK_means::calculateDistance(double x1, double x2)
{
    double part1 = (x2 - x1) * (x2 - x1);

    part1 = sqrt(part1);

    return part1;
}

/**
 * @brief CK_means::assignCentroid
 * @param x1
 * @param point
 * 计算中心点。
 */
void CK_means::assignCentroid(double x1, int point)
{
    double smallest = 99999;
    int chosenCentroid = 99999;

    for(int i = 0; i < k; i++)
    {
        double distanceToCentroid = calculateDistance(x1, centerX[i]);

//        qDebug()<<"distanceToCentroid = " + QString::number(distanceToCentroid);

        if( distanceToCentroid < smallest )
        {
            smallest = distanceToCentroid;
            chosenCentroid = i;
        }

    }
    assignSampleCenter[point] = chosenCentroid;

}


void CK_means::calculateNewCentroid()
{
    for( int i=0; i < k; i++)
    {
//        oldcenterX[i] = centerX[i];

        double xsum = 0;
        double count = 0;

        int KIndex = 0;

        for( int j=0; j < i32SampleIndex; j++)
        {
            qDebug()<<"check Before if assignSampleCenter[ " + QString::number(j) + " ] = " + QString::number(assignSampleCenter[j]);
            if(assignSampleCenter[j] == i)
            {
//                xsum += Samples[j];
//                count++;
                classK[i][KIndex++] = Samples[j];
//                KIndex++;
            }

        }
        if(count != 0) {
            centerX[i] = xsum / count;
        }


    }
}

void CK_means::ShowData()
{
    qDebug()<<"ShowData() :";
    for(int iIndex = 0; iIndex < i32SampleIndex; iIndex++) {
        qDebug()<< "Samples[ " + QString::number(iIndex) + " ] = " + QString::number(Samples[iIndex]);
    }

}


CK_means::~CK_means()
{
#if 1
    for(int iIndex = 0; iIndex < MAXDATACOUNT; iIndex++) {
        qDebug()<< "Samples[ " + QString::number(iIndex) + " ] = " + QString::number(Samples[iIndex]);
    }

    for(int i = 0; i < k; i++) {
        for(int j = 0; j < MAXDATACOUNT; j++) {
            qDebug()<< "classK[ " + QString::number(i) + " ] [ " + QString::number(j) + " ] = " + QString::number(classK[i][j]);
        }

    }

    qDebug()<<"centerX[0] = " + QString::number(centerX[0]) + "centerX[1] = " + QString::number(centerX[1]);
#endif
    delete []assignSampleCenter;
}
