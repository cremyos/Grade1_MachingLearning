Apriori
=======

C++ Implementation of Apriori Algorithm

To run the implementation 
=========================

Keep project files in one folder.

Compile apriori.cpp

run using following command:

  (For Linux/Mac)
  
  ./apriori > output.txt
  
  (For Windows)
  
  apriori.exe > output.txt
  
  
About input dataset
===================
each line represent a transaction , and each number represent a item.

-1 is used to terminate the particular transaction.
  
