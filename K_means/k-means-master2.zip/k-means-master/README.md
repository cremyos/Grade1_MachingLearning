k-means
=======

C++ implements k-means algorithm

Chinese Details: http://www.cnblogs.com/luxiaoxun/archive/2013/05/09/3069594.html

