# RBF-Radial-Basis-Function-Network
C++ Implementation of the RBF (Radial Basis Function) Network and choosing centroids using K-Means Plus Plus   

Achieving 100% Accuracy on both Training and testing Head Orientation Dataset (Facing Front - Facing Left - Facing Right)   
also with real-time camera testing support (remove OpenCv file reference if not interested in this feature)   

Download Data Set from here  
https://sites.google.com/a/fcis.asu.edu.eg/computer-science-department-2014-2015/2nd-term-announcements/neural-networks/vimpnnproject/Head%20Orientation%20Data%20set.rar
