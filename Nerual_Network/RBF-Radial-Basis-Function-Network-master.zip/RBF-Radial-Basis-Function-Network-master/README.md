# RBF-Radial-Basis-Function-Network  

C++ Implementation of the RBF (Radial Basis Function) Network and choosing centroids using K-Means++   

A Training Data of Head Orientations is used to test the Algorithm and for illustration purposes.  

The Implementation is based on CS 156 by Professor Yaser Abu-Mostafa Lectures.  

https://www.youtube.com/watch?v=O8CfrnOPtLc
